#!/usr/bin/bash

#echo "# myFtplugin" >> README.md
#git init
#git add *
#git commit -m "vim ftplugin commit"
#git remote add ftplugin https://github.com/hdeping/myFtplugin.git
git add $1
git push -u ftplugin master
